/* ------------------------------------------------------------------------ */
/* Copyright (c) 2024-2025 Cadence Design Systems, Inc. ALL RIGHTS RESERVED.*/
/* These coded instructions, statements, and computer programs ('Cadence    */
/* Libraries') are the copyrighted works of Cadence Design Systems Inc.     */
/* Cadence IP is licensed for use with Cadence processor cores only and     */
/* must not be used for any other processors and platforms. Your use of the */
/* Cadence Libraries is subject to the terms of the license agreement you   */
/* have entered into with Cadence Design Systems, or a sublicense granted   */
/* to you by a direct Cadence license.                                      */
/* ------------------------------------------------------------------------ */
/*  IntegrIT, Ltd.   www.integrIT.com, info@integrIT.com                    */
/*                                                                          */
/* NatureDSP Signal Library for HiFi 1 and 1s DSPs                          */
/*                                                                          */
/* This library contains copyrighted materials, trade secrets and other     */
/* proprietary information of IntegrIT, Ltd. This software is licensed for  */
/* use with Cadence processor cores only and must not be used for any other */
/* processors and platforms. The license to use these sources was given to  */
/* Cadence, Inc. under Terms and Condition of a Software License Agreement  */
/* between Cadence, Inc. and IntegrIT, Ltd.                                 */
/* ------------------------------------------------------------------------ */
/*          Copyright (c) 2009-2020 IntegrIT, Limited.                      */
/*                      All Rights Reserved.                                */
/* ------------------------------------------------------------------------ */
#ifndef __NATUREDSP_SIGNAL_MATOP_H__
#define __NATUREDSP_SIGNAL_MATOP_H__

#include "NatureDSP_types.h"

#ifdef __cplusplus
extern "C" {
#endif

/*===========================================================================
  Matrix Operations:
  mtx_mpy              Matrix Multiply
  mtx_vecmpy           Matrix by Vector Multiply
===========================================================================*/

/*-------------------------------------------------------------------------
  Matrix Multiply
  These functions compute the expression z = 2^lsh * x * y for the matrices 
  x and y. The columnar dimension of x must match the row dimension of y. 
  The resulting matrix has the same number of rows as x and the same number 
  of columns as y.
  NOTE: lsh factor is not relevant for floating point routines.

  Functions require scratch memory for storing intermediate data. This 
  scratch memory area should be aligned on 8 byte boundary and its size is 
  calculated by macros SCRATCH_MTX_MPY24X24(M,N,P), 
  SCRATCH_MTX_MPY32X32(M,N,P), SCRATCH_MTX_MPY16X16(M,N,P).

  Two versions of functions available: regular version (mtx_mpy32x32,
  mtx_mpy24x24, mtx_mpy16x16, mtx_mpyf) with arbitrary arguments and faster
  version (mtx_mpy32x32_fast, mtx_mpy24x24_fast, mtx_mpy16x16_fast, 
  mtx_mpyf_fast) that apply some restrictions.

  Precision:
  32x32 32-bit inputs, 32-bit output
  24x24 24-bit inputs, 24-bit output
  16x16 16-bit inputs, 16-bit output
  f     floating point

  Input:
  x[M*N]      input matrix x, Q15, Q31 or floating point
  y[N*P]      input matrix y, Q15, Q31 or floating point
  M           number of rows in matrix x and z
  N           number of columns in matrix x and number of rows in matrix y
  P           number of columns in matrices y and z
  lsh         left shift applied to the result (applied to the fixed-
              point functions only) 
  Output:
  z[M*P]      output matrix z, Q15, Q31 or floating point 
  Scratch:
  pScr        size in bytes defined by macros SCRATCH_MTX_MPY32X32,
              SCRATCH_MTX_MPY24X24, SCRATCH_MTX_MPY16X16

  Restrictions:
  For regular routines (mtx_mpy32x32, mtx_mpy24x24, mtx_mpy16x16, mtx_mpyf):
  x,y,z   should not overlap

  For faster routines (mtx_mpy32x32_fast, mtx_mpy24x24_fast, 
                       mtx_mpy16x16_fast, mtx_mpyf_fast):
  x,y,z   should not overlap
  x,y,z   aligned on 8-byte boundary
  M,N,P   multiplies of 4
  lsh     should be in range:
          -31...31 for mtx_mpy32x32, mtx_mpy32x32_fast,
                   mtx_mpy24x24, mtx_mpy24x24_fast
          -15...15 for mtx_mpy16x16, mtx_mpy16x16_fast  

-------------------------------------------------------------------------*/
void mtx_mpy32x32 ( void* pScr,
                    int32_t* restrict z,
              const int32_t* restrict x,
              const int32_t* restrict y,
              int M, int N, int P, int lsh );
void mtx_mpy24x24 ( void* pScr,
                    f24* restrict z,
              const f24* restrict x,
              const f24* restrict y,
              int M, int N, int P, int lsh );
void mtx_mpy16x16 ( void* pScr,
                    int16_t* restrict z,
              const int16_t* restrict x,
              const int16_t* restrict y,
              int M, int N, int P, int lsh );
void mtx_mpy32x32_fast ( int32_t* restrict z,
                   const int32_t* restrict x,
                   const int32_t* restrict y,
                   int M, int N, int P, int lsh );
void mtx_mpy24x24_fast ( f24* restrict z,
                   const f24* restrict x,
                   const f24* restrict y,
                   int M, int N, int P, int lsh );
void mtx_mpy16x16_fast ( int16_t* restrict z,
                   const int16_t* restrict x,
                   const int16_t* restrict y,
                   int M, int N, int P, int lsh );
void mtx_mpyf ( float32_t* restrict z,
          const float32_t* restrict x,
          const float32_t* restrict y,
          int M, int N, int P);
void mtx_mpyf_fast ( float32_t* restrict z,
               const float32_t* restrict x,
               const float32_t* restrict y,
               int M, int N, int P);

#define SCRATCH_MTX_MPY32X32(M,N,P) (((((N)>0?(N):0)+1)&(~1))*2*sizeof(int32_t) )
#define SCRATCH_MTX_MPY24X24(M,N,P) (((((N)>0?(N):0)+1)&(~1))*2*sizeof(f24))
#define SCRATCH_MTX_MPY16X16(M,N,P) (((((N)>0?(N):0)+3)&(~3))*4*sizeof(int16_t))

/*-------------------------------------------------------------------------
  Matrix by Vector Multiply
  These functions compute the expression z = 2^lsh * x * y for the matrices 
  x and vector y. 
  NOTE: lsh factor is not relevant for floating point routines.

  Two versions of functions available: regular version (mtx_vecmpy32x32, 
  mtx_vecmpy24x24, mtx_vecmpy16x16,mtx_vecmpyf) with arbitrary arguments 
  and faster version (mtx_vecmpy32x32_fast, mtx_vecmpy24x24_fast, 
  mtx_vecmpy16x16_fast, mtx_vecmpyf_fast) that apply some restrictions.

  Precision: 
  32x32 32-bit input, 32-bit output
  24x24 24-bit input, 24-bit output
  16x16 16-bit input, 16-bit output
  f     floating point

  Input:
  x[M*N] input matrix,Q31,Q15 or floating point
  y[N]   input vector,Q31,Q15 or floating point
  M      number of rows in matrix x
  N      number of columns in matrix x
  lsh    additional left shift(applied to the fixed-
         point functions only) 
  Output:
  z[M]   output vector,Q31,Q15 or floating point

  Restriction:
  For regular routines (mtx_vecmpy32x32, mtx_vecmpy24x24,
                        mtx_vecmpy16x16, mtx_vecmpyf)
  x,y,z should not overlap

  For faster routines (mtx_vecmpy32x32_fast, mtx_vecmpy24x24_fast,
                       mtx_vecmpy16x16_fast, mtx_vecmpyf_fast)
  x,y,z   should not overlap
  x,y     aligned on 8-byte boundary
  N, M    multiples of 4
  lsh     should be in range:
          -31...31 for mtx_vecmpy32x32, mtx_vecmpy32x32_fast,
                   mtx_vecmpy24x24, mtx_vecmpy24x24_fast
          -15...15 for mtx_vecmpy16x16, mtx_vecmpy16x16_fast  
-------------------------------------------------------------------------*/
void mtx_vecmpy32x32 ( int32_t* restrict z,
                 const int32_t* restrict x,
                 const int32_t* restrict y,
                 int M, int N, int lsh);
void mtx_vecmpy24x24 ( f24* restrict z,
                 const f24* restrict x,
                 const f24* restrict y,
                 int M, int N, int lsh);
void mtx_vecmpy16x16 ( int16_t* restrict z,
                 const int16_t* restrict x,
                 const int16_t* restrict y,
                 int M, int N, int lsh);
void mtx_vecmpy32x32_fast ( int32_t* restrict z,
                      const int32_t* restrict x,
                      const int32_t* restrict y,
                      int M, int N, int lsh);
void mtx_vecmpy24x24_fast ( f24* restrict z,
                      const f24* restrict x,
                      const f24* restrict y,
                      int M, int N, int lsh);
void mtx_vecmpy16x16_fast ( int16_t* restrict z,
                      const int16_t* restrict x,
                      const int16_t* restrict y,
                      int M, int N, int lsh);
void mtx_vecmpyf ( float32_t* restrict z,
             const float32_t* restrict x,
             const float32_t* restrict y,
             int M, int N);
void mtx_vecmpyf_fast ( float32_t* restrict z,
                  const float32_t* restrict x,
                  const float32_t* restrict y,
                  int M, int N);

/*-------------------------------------------------------------------------
  Operations with Small Matrices
  These functions implement basic operations under the sequence of small
  square matrices. Fixed point data are interpreted as Q15 or Q31 and
  results might be saturated.
  NOTE:
  Determinant is computed recursively via minors of submatrices. So, in
  the fixed-point routines, intermediate results might be saturated
  although final result is in range. To avoid this saturation, right shift
  might be applied at the first stage of computations. It means that final
  result would be represented in Q(15-rsh) or Q(31-rsh) respectively.
  Ad-hoc formula for rsh is rsh>=N-2 for real matrices and rsh>=N-1 for
  complex matrices.

  Precision:
  16x16  16-bit input, 16-bit output (real and complex)
  32x32  32-bit input, 32-bit output (real and complex)
  f      floating point (real and complex)

  Matrix dimensions are 2x2, 3x3, 4x4

  Input:
  x[L][N*N]      L input matrices
  y[L][N*N]      L input matrices (for addition, subtraction, multiply
                 functions)
  rsh            right shift for fixed-point multiply and determinant
                 function
  L              number of matrices
  Output:
  z[L][N*N]      L output matrices (for addition, subtraction, multiply,
                 transpose functions)
  d[L]           determinants for L matrices (for determinant functions)

  Restrictions:
  rsh should be in range 0..15
  x,y,z should not overlap
-------------------------------------------------------------------------*/
// real matrix addition
void mtx_add2x2_16x16(int16_t   * restrict z, const int16_t   *restrict x, const int16_t   *restrict y, int L);
void mtx_add3x3_16x16(int16_t   * restrict z, const int16_t   *restrict x, const int16_t   *restrict y, int L);
void mtx_add4x4_16x16(int16_t   * restrict z, const int16_t   *restrict x, const int16_t   *restrict y, int L);
void mtx_add2x2_32x32(int32_t   * restrict z, const int32_t   *restrict x, const int32_t   *restrict y, int L);
void mtx_add3x3_32x32(int32_t   * restrict z, const int32_t   *restrict x, const int32_t   *restrict y, int L);
void mtx_add4x4_32x32(int32_t   * restrict z, const int32_t   *restrict x, const int32_t   *restrict y, int L);
void mtx_add2x2f     (float32_t * restrict z, const float32_t *restrict x, const float32_t *restrict y, int L);
void mtx_add3x3f     (float32_t * restrict z, const float32_t *restrict x, const float32_t *restrict y, int L);
void mtx_add4x4f     (float32_t * restrict z, const float32_t *restrict x, const float32_t *restrict y, int L);

// complex matrix addition
void cmtx_add2x2_16x16(complex_fract16* restrict z, const complex_fract16 *restrict x, const complex_fract16 *restrict y, int L);
void cmtx_add3x3_16x16(complex_fract16* restrict z, const complex_fract16 *restrict x, const complex_fract16 *restrict y, int L);
void cmtx_add4x4_16x16(complex_fract16* restrict z, const complex_fract16 *restrict x, const complex_fract16 *restrict y, int L);
void cmtx_add2x2_32x32(complex_fract32* restrict z, const complex_fract32 *restrict x, const complex_fract32 *restrict y, int L);
void cmtx_add3x3_32x32(complex_fract32* restrict z, const complex_fract32 *restrict x, const complex_fract32 *restrict y, int L);
void cmtx_add4x4_32x32(complex_fract32* restrict z, const complex_fract32 *restrict x, const complex_fract32 *restrict y, int L);
void cmtx_add2x2f     (complex_float  * restrict z, const complex_float   *restrict x, const complex_float   *restrict y, int L);
void cmtx_add3x3f     (complex_float  * restrict z, const complex_float   *restrict x, const complex_float   *restrict y, int L);
void cmtx_add4x4f     (complex_float  * restrict z, const complex_float   *restrict x, const complex_float   *restrict y, int L);

// real matrix subtraction
void mtx_sub2x2_16x16(int16_t   * restrict z, const int16_t   *restrict x, const int16_t   *restrict y, int L);
void mtx_sub3x3_16x16(int16_t   * restrict z, const int16_t   *restrict x, const int16_t   *restrict y, int L);
void mtx_sub4x4_16x16(int16_t   * restrict z, const int16_t   *restrict x, const int16_t   *restrict y, int L);
void mtx_sub2x2_32x32(int32_t   * restrict z, const int32_t   *restrict x, const int32_t   *restrict y, int L);
void mtx_sub3x3_32x32(int32_t   * restrict z, const int32_t   *restrict x, const int32_t   *restrict y, int L);
void mtx_sub4x4_32x32(int32_t   * restrict z, const int32_t   *restrict x, const int32_t   *restrict y, int L);
void mtx_sub2x2f     (float32_t * restrict z, const float32_t *restrict x, const float32_t *restrict y, int L);
void mtx_sub3x3f     (float32_t * restrict z, const float32_t *restrict x, const float32_t *restrict y, int L);
void mtx_sub4x4f     (float32_t * restrict z, const float32_t *restrict x, const float32_t *restrict y, int L);

// complex matrix subtraction
void cmtx_sub2x2_16x16(complex_fract16* restrict z, const complex_fract16 *restrict x, const complex_fract16 *restrict y, int L);
void cmtx_sub3x3_16x16(complex_fract16* restrict z, const complex_fract16 *restrict x, const complex_fract16 *restrict y, int L);
void cmtx_sub4x4_16x16(complex_fract16* restrict z, const complex_fract16 *restrict x, const complex_fract16 *restrict y, int L);
void cmtx_sub2x2_32x32(complex_fract32* restrict z, const complex_fract32 *restrict x, const complex_fract32 *restrict y, int L);
void cmtx_sub3x3_32x32(complex_fract32* restrict z, const complex_fract32 *restrict x, const complex_fract32 *restrict y, int L);
void cmtx_sub4x4_32x32(complex_fract32* restrict z, const complex_fract32 *restrict x, const complex_fract32 *restrict y, int L);
void cmtx_sub2x2f     (complex_float  * restrict z, const complex_float   *restrict x, const complex_float   *restrict y, int L);
void cmtx_sub3x3f     (complex_float  * restrict z, const complex_float   *restrict x, const complex_float   *restrict y, int L);
void cmtx_sub4x4f     (complex_float  * restrict z, const complex_float   *restrict x, const complex_float   *restrict y, int L);

// real matrix multiply
void mtx_mul2x2_16x16(int16_t   * restrict z, const int16_t   *restrict x, const int16_t   *restrict y, int rsh, int L);
void mtx_mul3x3_16x16(int16_t   * restrict z, const int16_t   *restrict x, const int16_t   *restrict y, int rsh, int L);
void mtx_mul4x4_16x16(int16_t   * restrict z, const int16_t   *restrict x, const int16_t   *restrict y, int rsh, int L);
void mtx_mul2x2_32x32(int32_t   * restrict z, const int32_t   *restrict x, const int32_t   *restrict y, int rsh, int L);
void mtx_mul3x3_32x32(int32_t   * restrict z, const int32_t   *restrict x, const int32_t   *restrict y, int rsh, int L);
void mtx_mul4x4_32x32(int32_t   * restrict z, const int32_t   *restrict x, const int32_t   *restrict y, int rsh, int L);
void mtx_mul2x2f     (float32_t * restrict z, const float32_t *restrict x, const float32_t *restrict y,          int L);
void mtx_mul3x3f     (float32_t * restrict z, const float32_t *restrict x, const float32_t *restrict y,          int L);
void mtx_mul4x4f     (float32_t * restrict z, const float32_t *restrict x, const float32_t *restrict y,          int L);

// complex matrix multiply
void cmtx_mul2x2_16x16(complex_fract16 * restrict z, const complex_fract16 *restrict x, const complex_fract16 *restrict y, int rsh, int L);
void cmtx_mul3x3_16x16(complex_fract16 * restrict z, const complex_fract16 *restrict x, const complex_fract16 *restrict y, int rsh, int L);
void cmtx_mul4x4_16x16(complex_fract16 * restrict z, const complex_fract16 *restrict x, const complex_fract16 *restrict y, int rsh, int L);
void cmtx_mul2x2_32x32(complex_fract32 * restrict z, const complex_fract32 *restrict x, const complex_fract32 *restrict y, int rsh, int L);
void cmtx_mul3x3_32x32(complex_fract32 * restrict z, const complex_fract32 *restrict x, const complex_fract32 *restrict y, int rsh, int L);
void cmtx_mul4x4_32x32(complex_fract32 * restrict z, const complex_fract32 *restrict x, const complex_fract32 *restrict y, int rsh, int L);
void cmtx_mul2x2f     (complex_float   * restrict z, const complex_float   *restrict x, const complex_float   *restrict y,          int L);
void cmtx_mul3x3f     (complex_float   * restrict z, const complex_float   *restrict x, const complex_float   *restrict y,          int L);
void cmtx_mul4x4f     (complex_float   * restrict z, const complex_float   *restrict x, const complex_float   *restrict y,          int L);

// real matrix transpose
void mtx_tran2x2_16x16(int16_t   * restrict z, const int16_t   *restrict x, int L);
void mtx_tran3x3_16x16(int16_t   * restrict z, const int16_t   *restrict x, int L);
void mtx_tran4x4_16x16(int16_t   * restrict z, const int16_t   *restrict x, int L);
void mtx_tran2x2_32x32(int32_t   * restrict z, const int32_t   *restrict x, int L);
void mtx_tran3x3_32x32(int32_t   * restrict z, const int32_t   *restrict x, int L);
void mtx_tran4x4_32x32(int32_t   * restrict z, const int32_t   *restrict x, int L);
void mtx_tran2x2f     (float32_t * restrict z, const float32_t *restrict x, int L);
void mtx_tran3x3f     (float32_t * restrict z, const float32_t *restrict x, int L);
void mtx_tran4x4f     (float32_t * restrict z, const float32_t *restrict x, int L);

// complex matrix transpose
void cmtx_tran2x2_16x16(complex_fract16* restrict z, const complex_fract16 *restrict x, int L);
void cmtx_tran3x3_16x16(complex_fract16* restrict z, const complex_fract16 *restrict x, int L);
void cmtx_tran4x4_16x16(complex_fract16* restrict z, const complex_fract16 *restrict x, int L);
void cmtx_tran2x2_32x32(complex_fract32* restrict z, const complex_fract32 *restrict x, int L);
void cmtx_tran3x3_32x32(complex_fract32* restrict z, const complex_fract32 *restrict x, int L);
void cmtx_tran4x4_32x32(complex_fract32* restrict z, const complex_fract32 *restrict x, int L);
void cmtx_tran2x2f     (complex_float  * restrict z, const complex_float   *restrict x, int L);
void cmtx_tran3x3f     (complex_float  * restrict z, const complex_float   *restrict x, int L);
void cmtx_tran4x4f     (complex_float  * restrict z, const complex_float   *restrict x, int L);

// real matrix determinant
void mtx_det2x2_16x16(int16_t   * restrict z, const int16_t   *restrict x, int rsh, int L);
void mtx_det3x3_16x16(int16_t   * restrict z, const int16_t   *restrict x, int rsh, int L);
void mtx_det4x4_16x16(int16_t   * restrict z, const int16_t   *restrict x, int rsh, int L);
void mtx_det2x2_32x32(int32_t   * restrict z, const int32_t   *restrict x, int rsh, int L);
void mtx_det3x3_32x32(int32_t   * restrict z, const int32_t   *restrict x, int rsh, int L);
void mtx_det4x4_32x32(int32_t   * restrict z, const int32_t   *restrict x, int rsh, int L);
void mtx_det2x2f     (float32_t * restrict z, const float32_t *restrict x,          int L);
void mtx_det3x3f     (float32_t * restrict z, const float32_t *restrict x,          int L);
void mtx_det4x4f     (float32_t * restrict z, const float32_t *restrict x,          int L);

// complex matrix determinant
void cmtx_det2x2_16x16(complex_fract16 * restrict d, const complex_fract16 *restrict x, int rsh, int L);
void cmtx_det3x3_16x16(complex_fract16 * restrict d, const complex_fract16 *restrict x, int rsh, int L);
void cmtx_det4x4_16x16(complex_fract16 * restrict d, const complex_fract16 *restrict x, int rsh, int L);
void cmtx_det2x2_32x32(complex_fract32 * restrict d, const complex_fract32 *restrict x, int rsh, int L);
void cmtx_det3x3_32x32(complex_fract32 * restrict d, const complex_fract32 *restrict x, int rsh, int L);
void cmtx_det4x4_32x32(complex_fract32 * restrict d, const complex_fract32 *restrict x, int rsh, int L);
void cmtx_det2x2f     (complex_float   * restrict d, const complex_float   *restrict x,          int L);
void cmtx_det3x3f     (complex_float   * restrict d, const complex_float   *restrict x,          int L);
void cmtx_det4x4f     (complex_float   * restrict d, const complex_float   *restrict x,          int L);

/*-------------------------------------------------------------------------
  Quaternion to Rotation Matrix Conversion
  These functions convert sequence of unit quaternions to corresponding
  rotation matrices

  Precision:
  16x16  16-bit input, 16-bit output
  32x32  32-bit input, 32-bit output
  f      floating point

  Input:
  q[L][4]    L quaternions
  L          number of matrices
  Output:
  r[L][3*3]  L rotation matrices

  Restrictions:
  q,r  should not overlap
-------------------------------------------------------------------------*/
void q2rot_16x16(int16_t   *r, const int16_t   *q, int L);
void q2rot_32x32(int32_t   *r, const int32_t   *q, int L);
void q2rotf     (float32_t *r, const float32_t *q, int L);

/*-------------------------------------------------------------------------*/



#ifdef __cplusplus
}
#endif

#endif/* __NATUREDSP_SIGNAL_MATOP_H__ */
