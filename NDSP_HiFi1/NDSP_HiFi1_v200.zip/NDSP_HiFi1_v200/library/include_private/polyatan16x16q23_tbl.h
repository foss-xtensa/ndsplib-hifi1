/* ------------------------------------------------------------------------ */
/* Copyright (c) 2024-2025 Cadence Design Systems, Inc. ALL RIGHTS RESERVED.*/
/* These coded instructions, statements, and computer programs ('Cadence    */
/* Libraries') are the copyrighted works of Cadence Design Systems Inc.     */
/* Cadence IP is licensed for use with Cadence processor cores only and     */
/* must not be used for any other processors and platforms. Your use of the */
/* Cadence Libraries is subject to the terms of the license agreement you   */
/* have entered into with Cadence Design Systems, or a sublicense granted   */
/* to you by a direct Cadence license.                                      */
/* ------------------------------------------------------------------------ */
/*  IntegrIT, Ltd.   www.integrIT.com, info@integrIT.com                    */
/*                                                                          */
/* NatureDSP Signal Library for HiFi 1 and 1s DSPs                          */
/*                                                                          */
/* This library contains copyrighted materials, trade secrets and other     */
/* proprietary information of IntegrIT, Ltd. This software is licensed for  */
/* use with Cadence processor cores only and must not be used for any other */
/* processors and platforms. The license to use these sources was given to  */
/* Cadence, Inc. under Terms and Condition of a Software License Agreement  */
/* between Cadence, Inc. and IntegrIT, Ltd.                                 */
/* ------------------------------------------------------------------------ */
/*          Copyright (c) 2009-2020 IntegrIT, Limited.                      */
/*                      All Rights Reserved.                                */
/* ------------------------------------------------------------------------ */
#ifndef POLYATAN16X16Q23_TBL_H__
#define  POLYATAN16X16Q23_TBL_H__
/*
    tables for atan(x) approximation, q23
*/
#include "NatureDSP_types.h"

/* Matlab code for coefficients 
   x=(-1.1:pow2(1,-15):1.1);
   y=atan(x)/pi;
   p=polyfit(x,y,9);
   plot(x,y-polyval(p,x)); grid on
   p=p(1:2:end);
*/
extern const int32_t polyatan16x16q23[];

#endif /* POLYATAN16X16Q23_TBL_H__ */
