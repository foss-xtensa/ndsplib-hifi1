/* ------------------------------------------------------------------------ */
/* Copyright (c) 2024-2025 Cadence Design Systems, Inc. ALL RIGHTS RESERVED.*/
/* These coded instructions, statements, and computer programs ('Cadence    */
/* Libraries') are the copyrighted works of Cadence Design Systems Inc.     */
/* Cadence IP is licensed for use with Cadence processor cores only and     */
/* must not be used for any other processors and platforms. Your use of the */
/* Cadence Libraries is subject to the terms of the license agreement you   */
/* have entered into with Cadence Design Systems, or a sublicense granted   */
/* to you by a direct Cadence license.                                      */
/* ------------------------------------------------------------------------ */
/*  IntegrIT, Ltd.   www.integrIT.com, info@integrIT.com                    */
/*                                                                          */
/* NatureDSP Signal Library for HiFi 1 and 1s DSPs                          */
/*                                                                          */
/* This library contains copyrighted materials, trade secrets and other     */
/* proprietary information of IntegrIT, Ltd. This software is licensed for  */
/* use with Cadence processor cores only and must not be used for any other */
/* processors and platforms. The license to use these sources was given to  */
/* Cadence, Inc. under Terms and Condition of a Software License Agreement  */
/* between Cadence, Inc. and IntegrIT, Ltd.                                 */
/* ------------------------------------------------------------------------ */
/*          Copyright (c) 2009-2020 IntegrIT, Limited.                      */
/*                      All Rights Reserved.                                */
/* ------------------------------------------------------------------------ */

/*
  NatureDSP Signal Processing Library. FIR part
    Real block FIR filter, 24x24-bit, packed delay line and coefficient storage
    C code optimized for HiFi1
*/

/*-------------------------------------------------------------------------
  Real FIR filter.
  Computes a real FIR filter (direct-form) using IR stored in vector h. The 
  real data input is stored in vector x. The filter output result is stored 
  in vector y. The filter calculates N output samples using M coefficients 
  and requires last M-1 samples in the delay line.
  NOTE: 
  1. User application is not responsible for management of delay lines
  2. User has an option to set IR externally or copy from original location 
     (i.e. from the slower constant memory). In the first case, user is 
     responsible for right alignment, ordering and zero padding of filter 
     coefficients - usually array is composed from zeroes (left padding), 
     reverted IR and right zero padding.


  Precision: 
  16x16    16-bit data, 16-bit coefficients, 16-bit outputs
  24x24    24-bit data, 24-bit coefficients, 24-bit outputs
  24x24p   use 24-bit data packing for internal delay line buffer
           and internal coefficients storage
  32x16    32-bit data, 16-bit coefficients, 32-bit outputs
  32x32    32-bit data, 32-bit coefficients, 32-bit outputs
  f        floating point

  Input:
  x[N]     input samples, Q31, Q15, floating point
  h[M]     filter coefficients in normal order, Q31, Q15, floating point
  N        length of sample block, should be a multiple of 4
  M        length of filter, should be a multiple of 4
  extIR    if zero, IR is copied from original location, otherwise not
           but user should keep alignment, order of coefficients 
           and zero padding requirements shown below
  Output:
  y[N]     output samples, Q31, Q15, floating point

  Alignment, ordering and zero padding for external IR  (extIR!=0)
  ------------------------+----------+--------------+--------------+----------------
  Function                |Alignment,|Left zero     |   Coefficient| Right zero 
                          | bytes    |padding, bytes|   order      | padding, bytes
  ------------------------+----------+--------------+--------------+----------------
  bkfir16x16_init         |     8    |      2       |  inverted    |  6
  bkfir24x24_init         |     8    |      4       |  inverted    |  12
  bkfir24x24p_init        |     8    |((-M&4)+1)*3  |  inverted    |  7
  bkfir32x16_init (M>32)  |     8    |     10       |  inverted    |  6
  bkfir32x16_init (M<=32) |     8    |      2       |  inverted    |  6
  bkfir32x32_init         |     8    |      4       |  inverted    |  12
  bkfirf_init             |     8    |      0       |  direct      |  0
  ------------------------+----------+--------------+--------------+----------------

  Restrictions:
  x, y     should not be overlapping
  x, h     aligned on a 8-bytes boundary
  N, M     multiples of 4 
-------------------------------------------------------------------------*/


/* Portable data types. */
#include "NatureDSP_types.h"
/* Signal Processing Library API. */
#include "NatureDSP_Signal_fir.h"
/* Common utility and macros declarations. */
#include "common.h"

/* Instance pointer validation number. */
#define MAGIC     0x68c08c65

/* Reserve memory for alignment. */
#define ALIGNED_SIZE( size, align ) \
      ( (size_t)(size) + (align) - 1 )

/* Align address on a specified boundary. */
#define ALIGNED_ADDR( addr, align ) \
      (void*)( ( (uintptr_t)(addr) + ( (align) - 1 ) ) & ~( (align) - 1 ) )

/* 24-bit value packed into 3 bytes. */
typedef struct tag_f24p
{
  uint8_t b0; // Bits 7..0
  uint8_t b1; // Bits 15..8
  int8_t  b2; // Bits 23..16

} f24p;

#define sz_f24p  sizeof(f24p)

/* Filter instance structure. */
typedef struct tag_bkfir24x24_t
{
  int32_t magic;
  int             M; /* Filter length                   */
  const int32_t * h; /* Filter coefficients             */
  int32_t * d; /* Delay line of length M          */
  int32_t * p; /* Pointer into the delay line     */
} bkfir24x24p_t, *bkfir24x24p_ptr_t;

/* Calculate the memory block size for an FIR filter with given attributes. */
size_t bkfir24x24p_alloc( int M )
{
  NASSERT( M > 0 );
  NASSERT(M%4==0);
  M=(M+7)&~7;
  return 2*M*sizeof(int32_t) + sizeof(bkfir24x24p_t) + 7;
} // bkfir24x24p_alloc()

/* Initialize the filter structure. The delay line is zeroed. */
bkfirf_handle_t bkfir24x24p_init( void * objmem, int M, const f24 * h )
{
  bkfir24x24p_t* bkfir;
  void *           ptr;
  int32_t * restrict pd;
  int32_t * restrict ph;
  int m;
  NASSERT( objmem && M > 0 && h );
  NASSERT(M%4==0);
  NASSERT_ALIGN(h,8);
  /* Partition the memory block */
  ptr     = objmem;
  ph = (int32_t*)((((uintptr_t)ptr)+7)&~7);
  pd = ph+M;
  bkfir=(bkfir24x24p_t*)(pd+M);
  bkfir->magic=MAGIC;
  bkfir->M   = M;
  bkfir->h = ph;
  bkfir->d = bkfir->p = pd;
  /* copy coefficients and clean upd delay line */
  for (m=0; m<M; m++) ph[m]=h[m];
  for (m=0; m<M; m++) pd[m]=0;
  return bkfir;
} // bkfir24x24p_init()

/* process block of samples */
void bkfir24x24p_process( bkfir24x24p_handle_t _bkfir, 
                         f24 * restrict  y,
                   const f24 * restrict  x, int N )
{ 
    const ae_f32x2* restrict pH;
    const ae_f32x2* restrict pX;
          ae_f32x2* restrict pY;
    const ae_f32x2* pD01;
    const ae_f32x2* pD12;
    ae_f32x2* p;
    ae_valign  ay;
    int n,m,M;
    const int32_t* h;
    bkfir24x24p_t* bkfir;
    NASSERT(_bkfir);
    bkfir=(bkfir24x24p_t*)_bkfir;
    NASSERT(bkfir->magic==MAGIC);
    NASSERT(bkfir->h);
    NASSERT(bkfir->d);
    NASSERT(bkfir->p);
    NASSERT_ALIGN(bkfir->h,8);
    NASSERT_ALIGN(bkfir->d,8);
    NASSERT_ALIGN(bkfir->p,8);
    NASSERT(N%4==0);
    NASSERT_ALIGN(x,8);
    NASSERT((bkfir->M%4)==0);
    NASSERT(x);
    NASSERT(y);
    if(N<=0) return;
    M=bkfir->M;
    NASSERT(N>0);
    NASSERT(M>0);
    h=bkfir->h;
    pX=(const ae_f32x2*)x;
    WUR_AE_CBEGIN0( (uintptr_t)( bkfir->d            ) );
    WUR_AE_CEND0  ( (uintptr_t)( bkfir->d + bkfir->M ) );
    ay=AE_ZALIGN64();
    pY=(ae_f32x2*)y;
    p=(ae_f32x2*)(bkfir->p);
    
    for (n=0; n<N; n+=4)
    {   
        ae_f64     q0, q1, q2, q3;
        ae_f32x2   t,X01,X12,X23,X34,XN0,XN1,H01,H23;
        ae_valign  ad01,ad12;
       	ae_f32x2   d0;
 
        pH=(ae_f32x2* )h;
        pD01=(const ae_f32x2*)(p);
        pD12=(const ae_f32x2*)(((int32_t*)p)+1);
        AE_LA32X2NEG_PC(ad01,pD01);
        AE_LA32X2NEG_PC(ad12,pD12);
        AE_LA32X2_RIC(X12,ad12,pD12);
        AE_LA32X2_RIC(t,ad01,pD01);
        XN0=AE_L32X2_I(pX,0*sizeof(int32_t));
        XN1=AE_L32X2_I(pX,2*sizeof(int32_t));
        X12=AE_INTSWAP(XN0); 
        X34=AE_INTSWAP(XN1);
	
        X01=AE_SEL32_HL(XN0,t);
        X23=AE_SEL32_HL(XN1,XN0);        
            
        AE_L32X2_IP(H01,pH,2*sizeof(int32_t));
        q0=q1=AE_ZERO();
          
        q2=AE_MULF32R_HH(H01,X23);
        AE_MULAF32R_LL(q2,H01,X23);

        q3=AE_MULF32R_HH(H01,X34);
        AE_MULAF32R_LL(q3,H01,X34);
        
        __Pragma("loop_count min=1")
        for (m=0; m<M-2; m+=2)
        {
            AE_L32X2_IP(H23,pH,2*sizeof(int32_t));

            AE_MULAF32R_HH(q0,H01,X01);
            AE_MULAF32R_LL(q0,H01,X01);

            AE_MULAF32R_HH(q1,H01,X12);
            AE_MULAF32R_LL(q1,H01,X12);

            AE_MULAF32R_HH(q2,H23,X01);
            AE_MULAF32R_LL(q2,H23,X01);

            AE_MULAF32R_HH(q3,H23,X12);
            AE_MULAF32R_LL(q3,H23,X12);

            H01=H23; 

            AE_LA32X2_RIC(X01,ad01,pD01);
            AE_LA32X2_RIC(X12,ad12,pD12);
        }
	    	AE_MULAF32R_HH(q0,H01,X01);
        AE_MULAF32R_LL(q0,H01,X01);
        AE_MULAF32R_HH(q1,H01,X12);
        AE_MULAF32R_LL(q1,H01,X12);
  
        AE_L32X2_IP(XN0,pX,2*sizeof(int32_t));
        AE_L32X2_IP(XN1,pX,2*sizeof(int32_t));
        AE_S32X2_XC(XN0,p,8);
        AE_S32X2_XC(XN1,p,8);
        d0 = AE_ROUND24X2F48SASYM( q0, q1 );
        AE_SA32X2_IP( AE_SLAI32(d0, 8), ay, pY );
        d0 = AE_ROUND24X2F48SASYM( q2, q3 );
        AE_SA32X2_IP( AE_SLAI32(d0, 8), ay, pY );
    }
    AE_SA64POS_FP(ay,pY);
    bkfir->p=(int32_t*)p;
}
