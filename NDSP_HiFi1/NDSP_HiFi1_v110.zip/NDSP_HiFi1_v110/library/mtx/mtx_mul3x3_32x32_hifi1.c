/* ------------------------------------------------------------------------ */
/* Copyright (c) 2022 by Cadence Design Systems, Inc. ALL RIGHTS RESERVED.  */
/* These coded instructions, statements, and computer programs ('Cadence    */
/* Libraries') are the copyrighted works of Cadence Design Systems Inc.     */
/* Cadence IP is licensed for use with Cadence processor cores only and     */
/* must not be used for any other processors and platforms. Your use of the */
/* Cadence Libraries is subject to the terms of the license agreement you   */
/* have entered into with Cadence Design Systems, or a sublicense granted   */
/* to you by a direct Cadence license.                                      */
/* ------------------------------------------------------------------------ */
/*  IntegrIT, Ltd.   www.integrIT.com, info@integrIT.com                    */
/*                                                                          */
/* NatureDSP Signal Library                                                 */
/*                                                                          */
/* This library contains copyrighted materials, trade secrets and other     */
/* proprietary information of IntegrIT, Ltd. This software is licensed for  */
/* use with Cadence processor cores only and must not be used for any other */
/* processors and platforms. The license to use these sources was given to  */
/* Cadence, Inc. under Terms and Condition of a Software License Agreement  */
/* between Cadence, Inc. and IntegrIT, Ltd.                                 */
/* ------------------------------------------------------------------------ */
/*          Copyright (C) 2009-2022 IntegrIT, Limited.                      */
/*                      All Rights Reserved.                                */
/* ------------------------------------------------------------------------ */

/* Cross-platform data type definitions. */
#include "NatureDSP_types.h"
/* Signal Processing Library API. */
#include "NatureDSP_Signal.h" 
/* Common helper macros. */
#include "common.h"


/*-------------------------------------------------------------------------
  Operations with Small Matrices
  These functions implement basic operations under the sequence of small 
  square matrices. Fixed point data are interpreted as Q15 or Q31 and 
  results might be saturated.
  NOTE: 
  Determinant is computed recursively via minors of submatrices. So, in 
  the fixed-point routines, intermediate results might be saturated 
  although final result is in range. To avoid this saturation, right shift 
  might be applied at the first stage of computations. It means that final 
  result would be represented in Q(15-rsh) or Q(31-rsh) respectively. 
  Ad-hoc formula for rsh is rsh>=N-2 for real matrices and rsh>=N-1 for 
  complex matrices.

  Precision: 
  16x16  16-bit input, 16-bit output (real and complex)
  32x32  32-bit input, 32-bit output (real and complex)
  f      floating point (real and complex)

  Matrix dimensions are 2x2, 3x3, 4x4

  Input:
  x[L][N*N]      L input matrices
  y[L][N*N]      L input matrices (for addition, subtraction, multiply 
                 functions)
  rsh            right shift for fixed-point multiply and determinant 
                 function
  L              number of matrices
  Output:
  z[L][N*N]      L output matrices (for addition, subtraction, multiply, 
                 transpose functions)
  d[L]           determinants for L matrices (for determinant functions)

  Restrictions:
  rsh should be in range 0..15
  x,y,z should not overlap
-------------------------------------------------------------------------*/
/* real matrix multiply */
void mtx_mul3x3_32x32(int32_t   * restrict z, const int32_t   *restrict x, const int32_t   *restrict y, int rsh, int L)
{
#if 0
  const ae_int32x2    *  restrict py = (const ae_int32x2    *)y;
  ae_int32x2    *  pz = (ae_int32x2      *)z;
  const ae_int32x2    *  restrict px = (const ae_int32x2      *)x;
  int l, m;
  ae_int32x2 vx0, vy0, vx1, vy1, vx2, vy2, vy3, vy4;
  ae_int32x2 sx0, sx1, sx2;
  ae_int32x2 vz0, vz1, vz2;
  ae_f64 A0, A1, A2, A3;
  ae_valign      y_align, x_align, z_align;
  NASSERT_ALIGN(x, sizeof(*x));
  NASSERT_ALIGN(y, sizeof(*y));
  NASSERT_ALIGN(z, sizeof(*z));
  NASSERT(rsh >= 0 && rsh <= 15);
  x_align = AE_LA64_PP(px);
  z_align = AE_ZALIGN64();
  for (l = 0; l<L; l++,y+=3*3)
  {
    py = (const ae_int32x2    *)y;
    y_align = AE_LA64_PP(py);
    AE_LA32X2_IP(vy0, y_align, py);
    AE_LA32X2_IP(vy1, y_align, py);
    AE_LA32X2_IP(vy2, y_align, py);
    AE_LA32X2_IP(vy3, y_align, py);
    AE_LA32X2_IP(vy4, y_align, py);
    for (m=0;m<3;m++)
    {
      AE_L32_IP(sx0, px, 4);
      AE_L32_IP(sx1, px, 4);
      AE_L32_IP(sx2, px, 4);
      A0 = AE_MULF32R_HH(sx0, vy0);
      AE_MULAF32R_LL(A0, sx1, vy1);
      AE_MULAF32R_HH(A0, sx2, vy3);

      A1 = AE_MULF32R_HL(sx0, vy0);
      AE_MULAF32R_LH(A1, sx1, vy2);
      AE_MULAF32R_HL(A1, sx2, vy3);

      A2 = AE_MULF32R_HH(sx0, vy1);
      AE_MULAF32R_LL(A2, sx1, vy2);
      AE_MULAF32R_HH(A2, sx2, vy4);
    
      A0 = AE_SRAA64(A0, rsh);
      A1 = AE_SRAA64(A1, rsh);
      A2 = AE_SRAA64(A2, rsh);
      vz0 = AE_ROUND32X2F48SASYM(A0, A1);
      vz1 = AE_ROUND32X2F48SASYM(A2, A2);
      vz2 = AE_SEL32_HH(vz0, vz0);
      AE_S32_L_IP(vz2, pz, 4);
      AE_S32_L_IP(vz0, pz, 4);
      AE_S32_L_IP(vz1, pz, 4);
    }
  }
#else
  const ae_int32x2    *  restrict py = (const ae_int32x2    *)y;
        ae_int32x2    * restrict pz = (ae_int32x2      *)z;
  const ae_int32x2    *  restrict px = (const ae_int32x2      *)x;
  int l;
  ae_int32x2 vx0, vy0, vx1, vy1, vx2, vy2, vy3, vy4;
  ae_int32x2 sx0, sx1, sx2;
  ae_int32x2 vz0, vz1;
  #if (XCHAL_HW_VERSION < XTENSA_HWVERSION_RI_2022_9)
    ae_int32x2 vz2;
  #endif 
  
  ae_f64 A0, A1, A2, A3, A4, A5;
  ae_valign      y_align, x_align;
  NASSERT_ALIGN(x, sizeof(*x));
  NASSERT_ALIGN(y, sizeof(*y));
  NASSERT_ALIGN(z, sizeof(*z));
  NASSERT(rsh >= 0 && rsh <= 15);
  x_align = AE_LA64_PP(px);
  for (l = 0; l<L; l++)
  {
    py = (const ae_int32x2    *)(y + 9*l);
    px = (const ae_int32x2    *)(x + 9*l);
    y_align = AE_LA64_PP(py);
    x_align = AE_LA64_PP(px);
    AE_LA32X2_IP(vy0, y_align, py);
    AE_LA32X2_IP(vy1, y_align, py);
    AE_LA32X2_IP(vy2, y_align, py);
    AE_LA32X2_IP(vy3, y_align, py);
    AE_LA32X2_IP(vy4, y_align, py);

    AE_LA32X2_IP(vx0, x_align, px);
    AE_LA32X2_IP(vx1, x_align, px);
    AE_LA32X2_IP(vx2, x_align, px);
    A0 = AE_MULF32R_HH(vx0, vy0);
    AE_MULAF32R_LL(A0, vx0, vy1);
    AE_MULAF32R_HH(A0, vx1, vy3);

    A1 = AE_MULF32R_HL(vx0, vy0);
    AE_MULAF32R_LH(A1, vx0, vy2);
    AE_MULAF32R_HL(A1, vx1, vy3);

    A2 = AE_MULF32R_HH(vx0, vy1);
    AE_MULAF32R_LL(A2, vx0, vy2);
    AE_MULAF32R_HH(A2, vx1, vy4);

    A3 = AE_MULF32R_LH(vx1, vy0);
    AE_MULAF32R_HL(A3, vx2, vy1);
    AE_MULAF32R_LH(A3, vx2, vy3);

    A4 = AE_MULF32R_LL(vx1, vy0);
    AE_MULAF32R_HH(A4, vx2, vy2);
    AE_MULAF32R_LL(A4, vx2, vy3);

    A5 = AE_MULF32R_LH(vx1, vy1);
    AE_MULAF32R_HL(A5, vx2, vy2);
    AE_MULAF32R_LH(A5, vx2, vy4);
    A0 = AE_SRAA64(A0, rsh);
    A1 = AE_SRAA64(A1, rsh);
    A2 = AE_SRAA64(A2, rsh);
    vz0 = AE_ROUND32X2F48SASYM(A0, A0);
    vz1 = AE_ROUND32X2F48SASYM(A2, A1);
#if ( XCHAL_HW_VERSION >= XTENSA_HWVERSION_RI_2022_9)
      AE_S32_L_IP(vz0, castxcc(ae_int32,pz), 4);
      AE_S32_L_IP(vz1, castxcc(ae_int32,pz), 4);
      AE_S32_H_IP(vz1, castxcc(ae_int32,pz), 4);
#else
      vz2 = AE_SEL32_HH(vz1, vz1);
      AE_S32_L_IP(vz0, castxcc(ae_int32,pz), 4);
      AE_S32_L_IP(vz1, castxcc(ae_int32,pz), 4);
      AE_S32_L_IP(vz2, castxcc(ae_int32,pz), 4);
#endif

    A3 = AE_SRAA64(A3, rsh);
    A4 = AE_SRAA64(A4, rsh);
    A5 = AE_SRAA64(A5, rsh);
    vz0 = AE_ROUND32X2F48SASYM(A3, A3);
    vz1 = AE_ROUND32X2F48SASYM(A5, A4);
#if ( XCHAL_HW_VERSION >= XTENSA_HWVERSION_RI_2022_9 )
	  AE_S32_L_IP(vz0, castxcc(ae_int32,pz), 4);
	  AE_S32_L_IP(vz1, castxcc(ae_int32,pz), 4);
	  AE_S32_H_IP(vz1, castxcc(ae_int32,pz), 4*4);
#else
	  vz2 = AE_SEL32_HH(vz1, vz1);
	  AE_S32_L_IP(vz0, castxcc(ae_int32,pz), 4);
	  AE_S32_L_IP(vz1, castxcc(ae_int32,pz), 4);
	  AE_S32_L_IP(vz2, castxcc(ae_int32,pz), 4*4);
#endif
    
  }
  pz = (ae_int32x2      *)(z + 6);
  px = (const ae_int32x2      *)(x + 6);
  for (l = 0; l<L; l++, y+=3*3)
  {
    py = (const ae_int32x2    *)y;
    y_align = AE_LA64_PP(py);
    AE_LA32X2_IP(vy0, y_align, py);
    AE_LA32X2_IP(vy1, y_align, py);
    AE_LA32X2_IP(vy2, y_align, py);
    AE_LA32X2_IP(vy3, y_align, py);
    AE_LA32X2_IP(vy4, y_align, py);

    AE_L32_IP(sx0, castxcc(ae_int32,px), 4);
    AE_L32_IP(sx1, castxcc(ae_int32,px), 4);
    AE_L32_IP(sx2, castxcc(ae_int32,px), 4*7);
    A0 = AE_MULF32R_HH(sx0, vy0);
    AE_MULAF32R_LL(A0, sx1, vy1);
    AE_MULAF32R_HH(A0, sx2, vy3);

    A1 = AE_MULF32R_HL(sx0, vy0);
    AE_MULAF32R_LH(A1, sx1, vy2);
    AE_MULAF32R_HL(A1, sx2, vy3);

    A2 = AE_MULF32R_HH(sx0, vy1);
    AE_MULAF32R_LL(A2, sx1, vy2);
    AE_MULAF32R_HH(A2, sx2, vy4);
    A0 = AE_SRAA64(A0, rsh);
    A1 = AE_SRAA64(A1, rsh);
    A2 = AE_SRAA64(A2, rsh);
    vz0 = AE_ROUND32X2F48SASYM(A0, A0);
    vz1 = AE_ROUND32X2F48SASYM(A2, A1);

#if ( XCHAL_HW_VERSION >= XTENSA_HWVERSION_RI_2022_9 )
      AE_S32_L_IP(vz0, castxcc(ae_int32,pz), 4);
      AE_S32_L_IP(vz1, castxcc(ae_int32,pz), 4);
      AE_S32_H_IP(vz1, castxcc(ae_int32,pz), 4*7);
#else
      vz2 = AE_SEL32_HH(vz1, vz1);
      AE_S32_L_IP(vz0, castxcc(ae_int32,pz), 4);
      AE_S32_L_IP(vz1, castxcc(ae_int32,pz), 4);
      AE_S32_L_IP(vz2, castxcc(ae_int32,pz), 4*7);
#endif
  }
#endif
} /* mtx_mul3x3_32x32() */


