/* ------------------------------------------------------------------------ */
/* Copyright (c) 2024-2025 Cadence Design Systems, Inc. ALL RIGHTS RESERVED.*/
/* These coded instructions, statements, and computer programs ('Cadence    */
/* Libraries') are the copyrighted works of Cadence Design Systems Inc.     */
/* Cadence IP is licensed for use with Cadence processor cores only and     */
/* must not be used for any other processors and platforms. Your use of the */
/* Cadence Libraries is subject to the terms of the license agreement you   */
/* have entered into with Cadence Design Systems, or a sublicense granted   */
/* to you by a direct Cadence license.                                      */
/* ------------------------------------------------------------------------ */
/*  IntegrIT, Ltd.   www.integrIT.com, info@integrIT.com                    */
/*                                                                          */
/* NatureDSP Signal Library for HiFi 1 and 1s DSP                           */
/*                                                                          */
/* This library contains copyrighted materials, trade secrets and other     */
/* proprietary information of IntegrIT, Ltd. This software is licensed for  */
/* use with Cadence processor cores only and must not be used for any other */
/* processors and platforms. The license to use these sources was given to  */
/* Cadence, Inc. under Terms and Condition of a Software License Agreement  */
/* between Cadence, Inc. and IntegrIT, Ltd.                                 */
/* ------------------------------------------------------------------------ */
/*          Copyright (c) 2009-2020 IntegrIT, Limited.                      */
/*                      All Rights Reserved.                                */
/* ------------------------------------------------------------------------ */
/*
 * NatureDSP_Signal Library API
 * Matrix Operations
 * Annotations
*/

#include "NatureDSP_types.h"
#include "NatureDSP_Signal_matop.h"
#include "common.h"

ANNOTATE_FUN(mtx_mpy24x24,      	"Matrix Multiply (24-bit data)");
ANNOTATE_FUN(mtx_mpy32x32,      	"Matrix Multiply (32-bit data)");
ANNOTATE_FUN(mtx_mpy16x16,      	"Matrix Multiply (16-bit data)");
ANNOTATE_FUN(mtx_mpy24x24_fast, 	"Fast Matrix Multiply (24-bit data)");
ANNOTATE_FUN(mtx_mpy32x32_fast, 	"Fast Matrix Multiply (32-bit data)");
ANNOTATE_FUN(mtx_mpy16x16_fast, 	"Fast Matrix Multiply (16-bit data)");

ANNOTATE_FUN(mtx_vecmpy32x32,       "Matrix by Vector Multiply (32-bit data)");
ANNOTATE_FUN(mtx_vecmpy24x24,       "Matrix by Vector Multiply (24-bit data)");
ANNOTATE_FUN(mtx_vecmpy16x16,       "Matrix by Vector Multiply (16-bit data)");
ANNOTATE_FUN(mtx_vecmpy32x32_fast,  "Fast Matrix by Vector Multiply (32-bit data)");
ANNOTATE_FUN(mtx_vecmpy24x24_fast,  "Fast Matrix by Vector Multiply (24-bit data)");
ANNOTATE_FUN(mtx_vecmpy16x16_fast,  "Fast Matrix by Vector Multiply (16-bit data)");

ANNOTATE_FUN(mtx_mpyf,          	"Matrix Multiply (floating point data)");
ANNOTATE_FUN(mtx_mpyf_fast,     	"Fast Matrix Multiply (floating point data)");
ANNOTATE_FUN(mtx_vecmpyf,           "Matrix by Vector Multiply (floating point data)");
ANNOTATE_FUN(mtx_vecmpyf_fast,      "Fast Matrix by Vector Multiply (floating point data)");

ANNOTATE_FUN(mtx_add2x2_16x16,      "Real Matrix Addition (16-bit data)");
ANNOTATE_FUN(mtx_add3x3_16x16,      "Real Matrix Addition (16-bit data)");
ANNOTATE_FUN(mtx_add4x4_16x16,      "Real Matrix Addition (16-bit data)");
ANNOTATE_FUN(mtx_add2x2_32x32,      "Real Matrix Addition (32-bit data)");
ANNOTATE_FUN(mtx_add3x3_32x32,      "Real Matrix Addition (32-bit data)");
ANNOTATE_FUN(mtx_add4x4_32x32,      "Real Matrix Addition (32-bit data)");

ANNOTATE_FUN(mtx_add2x2f,      		"Real Matrix Addition (floating point data)");
ANNOTATE_FUN(mtx_add3x3f,      		"Real Matrix Addition (floating point data)");
ANNOTATE_FUN(mtx_add4x4f,      		"Real Matrix Addition (floating point data)");

ANNOTATE_FUN(cmtx_add2x2_16x16,     "Complex Matrix Addition (16-bit data)");
ANNOTATE_FUN(cmtx_add3x3_16x16,     "Complex Matrix Addition (16-bit data)");
ANNOTATE_FUN(cmtx_add4x4_16x16,     "Complex Matrix Addition (16-bit data)");
ANNOTATE_FUN(cmtx_add2x2_32x32,     "Complex Matrix Addition (32-bit data)");
ANNOTATE_FUN(cmtx_add3x3_32x32,     "Complex Matrix Addition (32-bit data)");
ANNOTATE_FUN(cmtx_add4x4_32x32,     "Complex Matrix Addition (32-bit data)");

ANNOTATE_FUN(cmtx_add2x2f,      	"Complex Matrix Addition (floating point data)");
ANNOTATE_FUN(cmtx_add3x3f,      	"Complex Matrix Addition (floating point data)");
ANNOTATE_FUN(cmtx_add4x4f,      	"Complex Matrix Addition (floating point data)");

ANNOTATE_FUN(mtx_sub2x2_16x16,      "Real Matrix Subtraction (16-bit data)");
ANNOTATE_FUN(mtx_sub3x3_16x16,      "Real Matrix Subtraction (16-bit data)");
ANNOTATE_FUN(mtx_sub4x4_16x16,      "Real Matrix Subtraction (16-bit data)");
ANNOTATE_FUN(mtx_sub2x2_32x32,      "Real Matrix Subtraction (32-bit data)");
ANNOTATE_FUN(mtx_sub3x3_32x32,      "Real Matrix Subtraction (32-bit data)");
ANNOTATE_FUN(mtx_sub4x4_32x32,      "Real Matrix Subtraction (32-bit data)");

ANNOTATE_FUN(mtx_sub2x2f,      		"Real Matrix Subtraction (floating point data)");
ANNOTATE_FUN(mtx_sub3x3f,      		"Real Matrix Subtraction (floating point data)");
ANNOTATE_FUN(mtx_sub4x4f,      		"Real Matrix Subtraction (floating point data)");

ANNOTATE_FUN(cmtx_sub2x2_16x16,     "Complex Matrix Subtraction (16-bit data)");
ANNOTATE_FUN(cmtx_sub3x3_16x16,     "Complex Matrix Subtraction (16-bit data)");
ANNOTATE_FUN(cmtx_sub4x4_16x16,     "Complex Matrix Subtraction (16-bit data)");
ANNOTATE_FUN(cmtx_sub2x2_32x32,     "Complex Matrix Subtraction (32-bit data)");
ANNOTATE_FUN(cmtx_sub3x3_32x32,     "Complex Matrix Subtraction (32-bit data)");
ANNOTATE_FUN(cmtx_sub4x4_32x32,     "Complex Matrix Subtraction (32-bit data)");

ANNOTATE_FUN(cmtx_sub2x2f,      	"Complex Matrix Subtraction (floating point data)");
ANNOTATE_FUN(cmtx_sub3x3f,      	"Complex Matrix Subtraction (floating point data)");
ANNOTATE_FUN(cmtx_sub4x4f,      	"Complex Matrix Subtraction (floating point data)");

ANNOTATE_FUN(mtx_mul2x2_16x16,      "Fast Matrix by Vector Multiply (16-bit data)");
ANNOTATE_FUN(mtx_mul3x3_16x16,      "Fast Matrix by Vector Multiply (16-bit data)");
ANNOTATE_FUN(mtx_mul4x4_16x16,      "Fast Matrix by Vector Multiply (16-bit data)");
ANNOTATE_FUN(mtx_mul2x2_32x32,      "Fast Matrix by Vector Multiply (32-bit data)");
ANNOTATE_FUN(mtx_mul3x3_32x32,      "Fast Matrix by Vector Multiply (32-bit data)");
ANNOTATE_FUN(mtx_mul4x4_32x32,      "Fast Matrix by Vector Multiply (32-bit data)");

ANNOTATE_FUN(mtx_mul2x2f,      		"Fast Matrix by Vector Multiply (floating point data)");
ANNOTATE_FUN(mtx_mul3x3f,      		"Fast Matrix by Vector Multiply (floating point data)");
ANNOTATE_FUN(mtx_mul4x4f,      		"Fast Matrix by Vector Multiply (floating point data)");

ANNOTATE_FUN(cmtx_mul2x2_16x16,     "Fast Matrix by Vector Multiply (16-bit data)");
ANNOTATE_FUN(cmtx_mul3x3_16x16,     "Fast Matrix by Vector Multiply (16-bit data)");
ANNOTATE_FUN(cmtx_mul4x4_16x16,     "Fast Matrix by Vector Multiply (16-bit data)");
ANNOTATE_FUN(cmtx_mul2x2_32x32,     "Fast Matrix by Vector Multiply (32-bit data)");
ANNOTATE_FUN(cmtx_mul3x3_32x32,     "Fast Matrix by Vector Multiply (32-bit data)");
ANNOTATE_FUN(cmtx_mul4x4_32x32,     "Fast Matrix by Vector Multiply (32-bit data)");

ANNOTATE_FUN(cmtx_mul2x2f,      	"Fast Matrix by Vector Multiply (floating point data)");
ANNOTATE_FUN(cmtx_mul3x3f,      	"Fast Matrix by Vector Multiply (floating point data)");
ANNOTATE_FUN(cmtx_mul4x4f,      	"Fast Matrix by Vector Multiply (floating point data)");

ANNOTATE_FUN(mtx_tran2x2_16x16,     "Real Matrix Transpose (16-bit data)");
ANNOTATE_FUN(mtx_tran3x3_16x16,     "Real Matrix Transpose (16-bit data)");
ANNOTATE_FUN(mtx_tran4x4_16x16,     "Real Matrix Transpose (16-bit data)");
ANNOTATE_FUN(mtx_tran2x2_32x32,     "Real Matrix Transpose (32-bit data)");
ANNOTATE_FUN(mtx_tran3x3_32x32,     "Real Matrix Transpose (32-bit data)");
ANNOTATE_FUN(mtx_tran4x4_32x32,     "Real Matrix Transpose (32-bit data)");

ANNOTATE_FUN(mtx_tran2x2f,          "Real Matrix Transpose (floating point data)");
ANNOTATE_FUN(mtx_tran3x3f,          "Real Matrix Transpose (floating point data)");
ANNOTATE_FUN(mtx_tran4x4f,          "Real Matrix Transpose (floating point data)");

ANNOTATE_FUN(cmtx_tran2x2_16x16,    "Complex Matrix Transpose (16-bit data)");
ANNOTATE_FUN(cmtx_tran3x3_16x16,    "Complex Matrix Transpose (16-bit data)");
ANNOTATE_FUN(cmtx_tran4x4_16x16,    "Complex Matrix Transpose (16-bit data)");
ANNOTATE_FUN(cmtx_tran2x2_32x32,    "Complex Matrix Transpose (32-bit data)");
ANNOTATE_FUN(cmtx_tran3x3_32x32,    "Complex Matrix Transpose (32-bit data)");
ANNOTATE_FUN(cmtx_tran4x4_32x32,    "Complex Matrix Transpose (32-bit data)");

ANNOTATE_FUN(cmtx_tran2x2f,         "Complex Matrix Transpose (floating point data)");
ANNOTATE_FUN(cmtx_tran3x3f,         "Complex Matrix Transpose (floating point data)");
ANNOTATE_FUN(cmtx_tran4x4f,         "Complex Matrix Transpose (floating point data)");

ANNOTATE_FUN(mtx_det2x2_16x16,      "Real Matrix Determinant (16-bit data)");
ANNOTATE_FUN(mtx_det3x3_16x16,      "Real Matrix Determinant (16-bit data)");
ANNOTATE_FUN(mtx_det4x4_16x16,      "Real Matrix Determinant (16-bit data)");
ANNOTATE_FUN(mtx_det2x2_32x32,      "Real Matrix Determinant (32-bit data)");
ANNOTATE_FUN(mtx_det3x3_32x32,      "Real Matrix Determinant (32-bit data)");
ANNOTATE_FUN(mtx_det4x4_32x32,      "Real Matrix Determinant (32-bit data)");

ANNOTATE_FUN(mtx_det2x2f,      		"Real Matrix Determinant (floating point data)");
ANNOTATE_FUN(mtx_det3x3f,      		"Real Matrix Determinant (floating point data)");
ANNOTATE_FUN(mtx_det4x4f,      		"Real Matrix Determinant (floating point data)");

ANNOTATE_FUN(cmtx_det2x2_16x16,     "Complex Matrix Determinant (16-bit data)");
ANNOTATE_FUN(cmtx_det3x3_16x16,     "Complex Matrix Determinant (16-bit data)");
ANNOTATE_FUN(cmtx_det4x4_16x16,     "Complex Matrix Determinant (16-bit data)");
ANNOTATE_FUN(cmtx_det2x2_32x32,     "Complex Matrix Determinant (32-bit data)");
ANNOTATE_FUN(cmtx_det3x3_32x32,     "Complex Matrix Determinant (32-bit data)");
ANNOTATE_FUN(cmtx_det4x4_32x32,     "Complex Matrix Determinant (32-bit data)");

ANNOTATE_FUN(cmtx_det2x2f,      	"Complex Matrix Determinant (floating point data)");
ANNOTATE_FUN(cmtx_det3x3f,      	"Complex Matrix Determinant (floating point data)");
ANNOTATE_FUN(cmtx_det4x4f,      	"Complex Matrix Determinant (floating point data)");

ANNOTATE_FUN(q2rot_16x16,      		"Quaternion to Rotation Matrix Conversion (16-bit point data)");
ANNOTATE_FUN(q2rot_32x32,      		"Quaternion to Rotation Matrix Conversion (floating point data)");
ANNOTATE_FUN(q2rotf,      			"Quaternion to Rotation Matrix Conversion (floating point data)");






