/* ------------------------------------------------------------------------ */
/* Copyright (c) 2024-2025 Cadence Design Systems, Inc. ALL RIGHTS RESERVED.*/
/* These coded instructions, statements, and computer programs ('Cadence    */
/* Libraries') are the copyrighted works of Cadence Design Systems Inc.     */
/* Cadence IP is licensed for use with Cadence processor cores only and     */
/* must not be used for any other processors and platforms. Your use of the */
/* Cadence Libraries is subject to the terms of the license agreement you   */
/* have entered into with Cadence Design Systems, or a sublicense granted   */
/* to you by a direct Cadence license.                                      */
/* ------------------------------------------------------------------------ */
/*  IntegrIT, Ltd.   www.integrIT.com, info@integrIT.com                    */
/*                                                                          */
/* NatureDSP Signal Library for HiFi 1 and 1s DSP                           */
/*                                                                          */
/* This library contains copyrighted materials, trade secrets and other     */
/* proprietary information of IntegrIT, Ltd. This software is licensed for  */
/* use with Cadence processor cores only and must not be used for any other */
/* processors and platforms. The license to use these sources was given to  */
/* Cadence, Inc. under Terms and Condition of a Software License Agreement  */
/* between Cadence, Inc. and IntegrIT, Ltd.                                 */
/* ------------------------------------------------------------------------ */
/*          Copyright (c) 2009-2020 IntegrIT, Limited.                      */
/*                      All Rights Reserved.                                */
/* ------------------------------------------------------------------------ */
/*
  NatureDSP Signal Processing Library. Math functions
    Division
    C code optimized for HiFi1
  IntegrIT, 2006-2018
*/
/* Signal Processing Library API. */
#include "NatureDSP_Signal_math.h"
#include "common.h"

/*===========================================================================
  Vector matematics:
  vec_divide           Division of Q31/Q15 Numbers
===========================================================================*/
/*-------------------------------------------------------------------------
  Division 
Fixed point routines perform pair-wise division of vectors written in Q31 or 
Q15 format. They return the fractional and exponential portion of the division 
result. Since the division may generate result greater than 1, it returns 
fractional portion frac in Q(31-exp) or or Q(15-exp) format and exponent 
exp so true division result in the Q0.31 may be found by shifting 
fractional part left by exponent value.
For division to 0, the result is not defined 

For fixed point finctions, mantissa accuracy is 2 LSB, so relative accuracy is:
vec_divide16x16, scl_divide16x16                   1.2e-4 
vec_divide24x24, scl_divide32x32, scl_divide24x24  4.8e-7 
vec_divide32x32                                    1.8e-9

Floating point routines operate with standard floating point numbers. Functions 
return +/-infinity in case of overflow and provide accuracy of 2 ULP.

Two versions of routines are available: regular versions (vec_divide32x32, 
vec_divide24x24, vec_divide16x16) work with arbitrary arguments, faster 
versions (vec_divide32x3_fast, vec_divide24x24_fast, vec_divide16x16_fast) 
apply some restrictions.

  Precision: 
  32x32  32-bit inputs, 32-bit output. 
  24x24  24-bit inputs, 24-bit output. 
  16x16  16-bit inputs, 16-bit output. 
  f      floating point

  Input:
  x[N]    nominator,Q31, Q15, floating point
  y[N]    denominator,Q31, Q15, floating point
  N       length of vectors
  Output:
  frac[N] fractional parts of result, Q(31-exp) or Q(15-exp) (for fixed 
          point functions)
  exp[N]  exponents of result (for fixed point functions) 
  z[N]    result (for floating point function)

  Restriction:
  For regular versions (vec_divide32x32, vec_divide24x24, 
  vec_divide16x16, vec_dividef) :
  x,y,frac,exp should not overlap

  For faster versions (vec_divide32x3_fast, vec_divide24x24_fast, 
  vec_divide16x16_fast) :
  x,y,frac,exp should not overlap
  x, y, frac to be aligned by 8-byte boundary, N - multiple of 4.

  Scalar versions:
  ----------------
  Return packed value (for fixed point functions): 
  scl_divide24x24(),scl_divide32x32():
  bits 23:0 fractional part
  bits 31:24 exponent
  scl_divide16x16():
  bits 15:0 fractional part
  bits 31:16 exponent
-------------------------------------------------------------------------*/

void vec_divide16x16 
(
  int16_t *       restrict  frac,
  int16_t *       restrict  exp,
  const int16_t * restrict  x,
  const int16_t * restrict  y,
  int M)
{
#define SCR_SZ (MAX_ALLOCA_SZ/sizeof(int16_t))
    int16_t ALIGN(8) scr[SCR_SZ];   /* local scratch */
    int n, N;
    const ae_int16   * restrict px;
    const ae_int16   * restrict py;
    ae_int16   * restrict pf;
    ae_int16   * restrict ps;
    const ae_p16s    * restrict pfRd;
    const ae_p16x2s  * restrict pfWr;
    const ae_p16x2s  * restrict psRd;

    while (M > 0)
    {
        N = XT_MIN(SCR_SZ, M); /* size of portion */
        /* take exponent and normalize inputs. Y is saved to the scratch */
        px = (const ae_int16 *)x;
        py = (const ae_int16 *)y;
        pf = (ae_int16 *)frac;
        ps = (ae_int16 *)scr;
        for (n = 0; n < N; n++)
        {
            ae_int16x4 X, Y;
            int expx, expy;
            AE_L16_IP(X, px, sizeof(int16_t));
            AE_L16_IP(Y, py, sizeof(int16_t));
            expx = AE_NSAZ16_0(X);
            expy = AE_NSAZ16_0(Y);
            X = AE_SLAA16S(X, expx);
            Y = AE_SLAA16S(Y, expy);
            AE_S16_0_IP(X, pf, sizeof(int16_t));
            AE_S16_0_IP(Y, ps, sizeof(int16_t));
            exp[n] = (int16_t)(expy - expx + 1);
        }
		ae_int32x2 Y;
        __Pragma("no_reorder");
        pfRd = (const ae_p16s  *)(frac - 1);
        pfWr = (ae_p16x2s*)(frac - 1);
        psRd = (const ae_p16x2s*)(scr);
		AE_L16X2M_IU(Y, psRd, 0); //preload initial  2 elements
        for (n = 0; n < (N&~1); n += 2)
        {
            ae_int32x2 E, X, X_temp, Z;
            ae_f32x2 f;
            xtbool2 sy;
            ae_int32x2 _0x400000 = AE_MOVDA32(0x400000);
            Y = AE_SLAI32S(Y, 8);
            sy = AE_LT32(Y, AE_ZERO32());
            X = AE_ABS32S(Y);
            /* first approximation */
            X_temp = AE_SRAI32(X, 8);
            Y = AE_SUB32(AE_MOVDA32((int32_t)0x00BAEC00), X_temp);

            /* 3 iterations to achieve 1 LSB accuracy in mantissa */
            f = AE_MOVF32X2_FROMINT32X2(_0x400000);
            AE_MULSFP32X2RAS(f, X, Y);
            E = AE_MOVINT32X2_FROMF32X2(f);
            E = AE_SLLI32(E, 1+8);
            f = AE_MOVF32X2_FROMINT32X2(Y);
            AE_MULAFP32X2RAS(f, E, Y);
            Y = AE_MOVINT32X2_FROMF32X2(f);
            f = AE_MOVF32X2_FROMINT32X2(_0x400000);
            AE_MULSFP32X2RAS(f, X, Y);
            E = AE_MOVINT32X2_FROMF32X2(f);
            E = AE_SLLI32(E, 1+8);
            f = AE_MOVF32X2_FROMINT32X2(Y);
            AE_MULAFP32X2RAS(f, E, Y);
            Y = AE_MOVINT32X2_FROMF32X2(f);
            f = AE_MOVF32X2_FROMINT32X2(_0x400000);
            AE_MULSFP32X2RAS(f, X, Y);
            E = AE_MOVINT32X2_FROMF32X2(f);
            E = AE_SLLI32(E, 1+8);
            f = AE_MOVF32X2_FROMINT32X2(Y);
            AE_MULAFP32X2RAS(f, E, Y);
            Y = AE_MOVINT32X2_FROMF32X2(f);
            /* restore original sign */
            Z = AE_NEG32(Y);
            AE_MOVT32X2(Y, Z, sy);
            Y = AE_SLAI32S(Y,8);
            AE_L16M_IU(X, pfRd, 2);
            Z = AE_MULFP32X2RAS_L(X, AE_INTSWAP(Y));
            AE_S16M_L_IU(Z, castxcc(ae_p16s, pfWr), 2);
            AE_L16M_IU(X, pfRd, 2);
            Z = AE_MULFP32X2RAS_L(X, Y);
            AE_S16M_L_IU(Z, castxcc(ae_p16s, pfWr), 2);	
            AE_L16X2M_IU(Y, psRd, 4);
        }
        if (N & 1)
        {
            ae_int32x2  E, X, X_temp, Z;
            ae_f32x2 f;
            xtbool2 sy;
            ae_int32x2 _0x400000 = AE_MOVDA32(0x400000);          
            Y = AE_SEL32_HH(Y,Y);
            Y = AE_SLAI32S(Y, 8);
            sy = AE_LT32(Y, AE_ZERO32());
            X = AE_ABS32S(Y);
            /* first approximation */
            X_temp = AE_SRAI32(X, 8);
            Y = AE_SUB32(AE_MOVDA32((int32_t)0x00BAEC00), X_temp);

            /* 3 iterations to achieve 1 LSB accuracy in mantissa */
            f = AE_MOVF32X2_FROMINT32X2(_0x400000);
            AE_MULSFP32X2RAS_L(f, X, Y);
            E = AE_MOVINT32X2_FROMF32X2(f);
            E = AE_SLLI32(E, 1+8);
            f = AE_MOVF32X2_FROMINT32X2(Y);
            AE_MULAFP32X2RAS_L(f, E, Y);
            Y = AE_MOVINT32X2_FROMF32X2(f);
            f = AE_MOVF32X2_FROMINT32X2(_0x400000);
            AE_MULSFP32X2RAS_L(f, X, Y);
            E = AE_MOVINT32X2_FROMF32X2(f);
            E = AE_SLLI32(E, 1+8);
            f = AE_MOVF32X2_FROMINT32X2(Y);
            AE_MULAFP32X2RAS_L(f, E, Y);
            Y = AE_MOVINT32X2_FROMF32X2(f);
            f = AE_MOVF32X2_FROMINT32X2(_0x400000);
            AE_MULSFP32X2RAS_L(f, X, Y);
            E = AE_MOVINT32X2_FROMF32X2(f);
            E = AE_SLLI32(E, 1+8);
            f = AE_MOVF32X2_FROMINT32X2(Y);
            AE_MULAFP32X2RAS_L(f, E, Y);
            Y = AE_MOVINT32X2_FROMF32X2(f);
            /* restore original sign */
            Z = AE_NEG32(Y);
            AE_MOVT32X2(Y, Z, sy);
            Y = AE_SLAI32S(Y, 8);
            AE_L16M_IU(X, pfRd, 2);
            Z = AE_MULFP32X2RAS_L(X, Y);
            AE_S16M_L_IU(Z, castxcc(ae_p16s, pfWr), 2);
        }
        /* process next portion */
        M -= N;
        x += N;
        y += N;
        frac += N;
        exp += N;
    }
} /* vec_divide16x16() */
